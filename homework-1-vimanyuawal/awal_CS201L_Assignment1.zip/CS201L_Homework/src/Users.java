import java.util.ArrayList;
import java.util.Comparator;

public class Users {
	public Name Name;
	public ArrayList <Events> Events;
	public Name getName() {
		return Name;
	}
	public void setName(Name name) {
		this.Name = name;
	}
	public ArrayList<Events> getEvents() {
		return Events;
	}
	public void setEvents(ArrayList<Events> eventsArray) {
		this.Events = eventsArray;
	}
}
