
public class Date {
	public String Month;
	public String Day;
	public int Year;
	public String getMonth() {
		return Month;
	}
	public void setMonth(String month) {
		this.Month = month;
	}
	public String getDay() {
		return Day;
	}
	public void setDay(String day) {
		this.Day = day;
	}
	public int getYear() {
		return Year;
	}
	public void setYear(int year) {
		this.Year = year;
	}
}
