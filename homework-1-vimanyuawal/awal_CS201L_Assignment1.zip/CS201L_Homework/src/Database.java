import java.util.ArrayList;
import java.util.Comparator;

public class Database {
	public ArrayList <Users> Users;

	public ArrayList<Users> getUsers() {
		return Users;
	}

	public void setUsersArray(ArrayList<Users> Users) {
		this.Users = Users;
	}
	
	public static Comparator<Users> asc = new Comparator<Users>() {

		public int compare(Users u1, Users u2) {
		   String UserName1 = u1.getName().getLname().toUpperCase();
		   String UserName2 = u2.getName().getLname().toUpperCase();
		   return UserName1.compareTo(UserName2);
		}
	};

	public static Comparator<Users> desc = new Comparator<Users>() {

		public int compare(Users u1, Users u2) {
		   String UserName1 =  u1.getName().getLname().toUpperCase();
		   String UserName2 = u2.getName().getLname().toUpperCase();
		   int ret = UserName1.compareTo(UserName2);
		   return -ret;
		}
	};
}
