
public class Name {
	public String Fname;
	public String Lname;
	public String getFname() {
		return Fname;
	}
	public void setFname(String Fname) {
		this.Fname = Fname;
	}
	public String getLname() {
		return Lname;
	}
	public void setLname(String Lname) {
		this.Lname = Lname;
	}
}
