import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Scanner;

import com.google.gson.Gson;

public class Main {
	public static void main(String [] args)
	{
		Gson gson = new Gson();
		Scanner sc = new Scanner(System.in);
		boolean flag = false;
		boolean saved = true;
		Database data = null;
		String filename = null;
		while(flag == false)
		{
			try
			{
				System.out.print("What is the name of the input file? ");
				filename = sc.nextLine();
				System.out.println(filename);
				BufferedReader freader = new BufferedReader(new FileReader(filename));

				data = gson.fromJson(freader, Database.class);
				System.out.println(data.getUsers().size());
				flag = true;
			}
			catch(FileNotFoundException fnfe)
			{
				System.out.println("That file could not be found.");
			}
		}
		
		while(1 > 0)
		{
			System.out.println("1) Display User's Calendar");
			System.out.println("2) Add User");
			System.out.println("3) Remove User");
			System.out.println("4) Add Event");
			System.out.println("5) Delete Event");
			System.out.println("6) Sort Users");
			System.out.println("7) Write File");
			System.out.println("8) Exit");
			int input = sc.nextInt();
				
				if(input == 1)
				{
					int length = data.getUsers().size();
					for(int i = 0; i < length; i++)
					{
						System.out.println((i+1) + ") " + data.getUsers().get(i).getName().getLname() + ", " + data.getUsers().get(i).getName().getFname());
						if(data.getUsers().get(i).getEvents() != null)
						{
						
							int length2 =  data.getUsers().get(i).getEvents().size();
							for(int j = 0; j < length2; j++)
							{
								System.out.print("\t" + (char)('a'+j) + ". " + data.getUsers().get(i).getEvents().get(j).getTitle() + ", ");
								System.out.print(data.getUsers().get(i).getEvents().get(j).getTime() + ", ");
								System.out.println(data.getUsers().get(i).getEvents().get(j).getDate().getMonth()
										+ " " + data.getUsers().get(i).getEvents().get(j).getDate().getDay()
										+ ", " + data.getUsers().get(i).getEvents().get(j).getDate().getYear());
							}
						}
					}
				}
				
				else if(input == 2)
				{
					System.out.println("What is the user's name? ");
					String first_name = sc.next();
					String last_name = sc.nextLine();
					Name newName = new Name();
					newName.setFname(first_name);
					newName.setLname(last_name);
					Users newUser = new Users();
					newUser.setName(newName);
					ArrayList<Users> ogUsers = data.getUsers();
					ogUsers.add(newUser);
					saved = false;
				}
				
				else if(input == 3)
				{
					int length = data.getUsers().size();
					for(int i = 0; i < length; i++)
					{
						System.out.println((i+1) + ") " + data.getUsers().get(i).getName().getLname() + ", " + data.getUsers().get(i).getName().getFname());
					}
					
					System.out.println("Which user would you like to remove? ");
					int choice = sc.nextInt();
					data.getUsers().remove(choice-1);
					saved = false;
				}
				
				else if(input == 4)
				{
					int length = data.getUsers().size();
					for(int i = 0; i < length; i++)
					{
						System.out.println((i+1) + ") " + data.getUsers().get(i).getName().getLname() + ", " + data.getUsers().get(i).getName().getFname());
					}
	
					System.out.println("To which user would you like to add an event?");
					int userForEvent = sc.nextInt();
					userForEvent--;
					ArrayList<Events> originalEvents = new ArrayList<Events>();
					if(null != data.getUsers().get(userForEvent).getEvents())
						originalEvents = data.getUsers().get(userForEvent).getEvents();

					Events newEvent = new Events();
					System.out.println("What is the title of the event?");
					sc.nextLine();
					String title = sc.nextLine();
					System.out.println("What time is the event?");
					String time = sc.nextLine();
					System.out.println("What month?");
					String month = sc.nextLine();
					System.out.println("What day?");
					String day = sc.nextLine();
					System.out.println("What year?");
					int year = sc.nextInt();
					sc.nextLine();
					Date date = new Date();
					date.setDay(day);
					date.setMonth(month);
					date.setYear(year);
					newEvent.setTitle(title);
					newEvent.setDate(date);
					newEvent.setTime(time);
					originalEvents.add(newEvent);
					data.getUsers().get(userForEvent).setEvents(originalEvents);						
						
					System.out.println("Added: " + title + ", " + time + ", " + month + " " + day + ", " + year + " to " + data.getUsers().get(userForEvent).getName().getFname() + " " +data.getUsers().get(userForEvent).getName().getLname() + "'s calendar.");
					
					saved = false;
				}
				
				else if(input == 5)//delete an event
				{
					int length = data.getUsers().size();
					for(int i = 0; i < length; i++)
					{
						System.out.println((i+1) + ") " + data.getUsers().get(i).getName().getLname() + ", " + data.getUsers().get(i).getName().getFname());
					}
					
					System.out.println("From which user would you like to delete an event? ");
					int toDeleteFrom = sc.nextInt();
					toDeleteFrom--;
					int eventsArraySize = data.getUsers().get(toDeleteFrom).getEvents().size();
					if(eventsArraySize == 0)
					{
						System.out.println("Calendar is empty.");
					}
					else
					{
						for(int i = 0; i < eventsArraySize; i++)
						{
							System.out.println((i+1) + ") " + data.getUsers().get(toDeleteFrom).getEvents().get(i).getTitle() +
												", " + data.getUsers().get(toDeleteFrom).getEvents().get(i).getTime() + ", "
												+ data.getUsers().get(toDeleteFrom).getEvents().get(i).getDate().getMonth() + " " + 
												data.getUsers().get(toDeleteFrom).getEvents().get(i).getDate().getDay() + ", " +
												data.getUsers().get(toDeleteFrom).getEvents().get(i).getDate().getYear());
						}
						
						System.out.println("Which event would you like to delete? ");
						int eventToDelete = sc.nextInt();
						eventToDelete--;
						System.out.println(data.getUsers().get(toDeleteFrom).getEvents().get(eventToDelete).getTitle() + " has been deleted.");
						data.getUsers().get(toDeleteFrom).getEvents().remove(eventToDelete);
					}
					
					saved = false;
				}
				
				else if(input == 6)//sort users
				{
					System.out.println("1) Ascending (A-Z)" + "\n2) Descending (Z-A)");
					int choice = sc.nextInt();
					
					if(choice == 1)
					{
						Collections.sort(data.getUsers(), Database.asc);
					}
					
					else
					{
						Collections.sort(data.getUsers(), Database.desc);
					}
					
					for(int i = 0; i < data.getUsers().size(); i++)
					{
						System.out.println((i+1) + ") " + data.getUsers().get(i).getName().getLname() + ", " + data.getUsers().get(i).getName().getFname());
					}
					
					saved = false;
				}
				
				else if(input == 7)//write file
				{
					String jsonLine = gson.toJson(data);
					FileWriter fw;
					try {
						fw = new FileWriter(filename);
						fw.write(jsonLine);
						fw.close();
					}
					
					catch (IOException ioe)
					{
						ioe.printStackTrace();
					}
					saved = true;
					System.out.println("The file has been saved.");
				}
				
				else if(input == 8)//Exit
				{
					//if the file has been changed then give option to save
					if (saved == false)
					{
						System.out.println("Changes have been made since the file was last saved. \n 1) Yes \n 2) No \n Would you like to save the file before exiting? ");
						int choice = sc.nextInt();
						
						if(choice == 2)
						{
							System.out.println("File was not saved. ");
						}
						
						else if(choice == 1)
						{
							String jsonLine = gson.toJson(data);
							FileWriter fw;
							try {
								fw = new FileWriter(filename);
								fw.write(jsonLine);
								fw.close();
							}
							
							catch (IOException ioe)
							{
								ioe.printStackTrace();
							}
							saved = true;
							System.out.println("The file has been saved.");
						}
						
						else
						{
							System.out.println("Invalid option. File was not saved.");
						}
					}
					
					//else
					System.out.println("Thank you for using my program.");
					System.exit(0);
				}
				
				else
				{
					System.out.println("That is not a valid option");
				}
			}	
			
		}
}

